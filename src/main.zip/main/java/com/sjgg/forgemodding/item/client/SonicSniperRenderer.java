package com.sjgg.forgemodding.item.client;

import com.sjgg.forgemodding.item.custom.SonicSniperItem;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class SonicSniperRenderer extends GeoItemRenderer<SonicSniperItem> {
    public SonicSniperRenderer() {
        super(new SonicSniperModel());
    }
}