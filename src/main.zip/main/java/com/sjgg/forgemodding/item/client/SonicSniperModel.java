package com.sjgg.forgemodding.item.client;

import com.sjgg.forgemodding.item.custom.SonicSniperItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SonicSniperModel extends GeoModel<SonicSniperItem> {
    @Override
    public ResourceLocation getModelResource(SonicSniperItem animatable) {
        return ResourceLocation.tryParse("forgemodding:geo/sonic_sniper.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SonicSniperItem animatable) {
        return ResourceLocation.tryParse("forgemodding:textures/item/sonic_sniper.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SonicSniperItem animatable) {
        return null;
    }
}